
// //   Import the functions you need from the SDKs you need
//   async function asd(){ $.getScript("https://www.gstatic.com/firebasejs/9.1.2/firebase-app.js").then(()=>$.getScript(
//   "https://www.gstatic.com/firebasejs/9.1.2/firebase-firestore.js")).then(()=>$.getScript("https://www.gstatic.com/firebasejs/9.1.2/firebase-analytics.js")).then(async()=>{

//  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
//  const firebaseConfig = {
//     apiKey: "AIzaSyCucSsx70B9ZalMCZYHw2pQNKvhwzAK8TI",
//     authDomain: "ayaan-5c50d.firebaseapp.com",
//     projectId: "ayaan-5c50d",
//     storageBucket: "ayaan-5c50d.appspot.com",
//     messagingSenderId: "404490931179",
//     appId: "1:404490931179:web:4afecfee788d86922627ae",
//     measurementId: "G-W0W9KXS9RQ"
//   };

//   // Initialize Firebase
//    const app = await initializeApp(firebaseConfig);
//   const analytics = await getAnalytics(app);



//   })



// }
//   // TODO: Add SDKs for Firebase products that you want to use
//   // https://firebase.google.com/docs/web/setup#available-libraries

//   // Your web app's Firebase configuration
//  asd()